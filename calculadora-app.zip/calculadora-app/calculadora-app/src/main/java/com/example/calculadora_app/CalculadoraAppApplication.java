package com.example.calculadora_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadoraAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculadoraAppApplication.class, args);
	}

}
