package com.example.calculadora_app.model;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Operacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String tipo;
    private Double numero1;
    private Double numero2;
    private Double resultado;

    @Column(nullable = false)
    private LocalDateTime dataHora;

    public Operacao(Object o, String soma, double v, double v1, double v2, LocalDateTime now) {
    }

    public String getTipo() {
        return "";
    }

    public double getResultado() {
        return 0;
    }
}

