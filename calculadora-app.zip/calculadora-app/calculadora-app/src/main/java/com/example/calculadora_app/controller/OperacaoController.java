package com.example.calculadora_app.controller;

import com.example.calculadora_app.model.Operacao;
import com.example.calculadora_app.service.OperacaoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/api/v1/calculadora")
@RequiredArgsConstructor
public class OperacaoController {

    private final OperacaoService service;

    public OperacaoController(OperacaoService service) {
        this.service = service;
    }

    @PostMapping("/{operacao}")
    public ResponseEntity<Operacao> calcular(
            @PathVariable String operacao,
            @RequestParam Double numero1,
            @RequestParam Double numero2) {

        double resultado;

        switch (operacao.toLowerCase()) {
            case "soma":
                resultado = numero1 + numero2;
                break;
            case "subtracao":
                resultado = numero1 - numero2;
                break;
            case "multiplicacao":
                resultado = numero1 * numero2;
                break;
            case "divisao":
                if (numero2 == 0) {
                    throw new ArithmeticException("Divisão por zero não é permitida.");
                }
                resultado = numero1 / numero2;
                break;
            default:
                throw new IllegalArgumentException("Operação inválida.");
        }

        return ResponseEntity.ok(service.salvarOperacao(operacao.toUpperCase(), numero1, numero2, resultado));
    }

    @GetMapping("/historico")
    public ResponseEntity<List<Operacao>> historico() {
        return ResponseEntity.ok(service.listarHistorico());
    }
}
