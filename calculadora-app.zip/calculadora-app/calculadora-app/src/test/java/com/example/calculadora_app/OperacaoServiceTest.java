package com.example.calculadora_app;

import com.example.calculadora_app.model.Operacao;
import com.example.calculadora_app.repository.OperacaoRepository;
import com.example.calculadora_app.service.OperacaoService;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import static org.mockito.Mockito.when;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;


class OperacaoServiceTest {

    @InjectMocks
    private OperacaoService service;

    @Mock
    private OperacaoRepository repository;

    @Test
    void testSalvarOperacao() {
        MockitoAnnotations.openMocks(this);

        Operacao operacao = new Operacao(null, "SOMA", 1.0, 2.0, 3.0, LocalDateTime.now());
        when(repository.save(any())).thenReturn(operacao);

        Operacao resultado = service.salvarOperacao("SOMA", 1.0, 2.0, 3.0);

        assertEquals("SOMA", resultado.getTipo());
        assertEquals(3.0, resultado.getResultado());
    }
}
